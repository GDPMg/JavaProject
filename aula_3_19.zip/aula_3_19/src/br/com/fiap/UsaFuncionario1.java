package fiap.com.br;

public class UsaFuncionario1 {

	public static void main(String[] args) {
		Funcionario fun = new Funcionario();
		fun.setNome("Guilherme");
		fun.setValorHora(30.5f);
		System.out.println("O salario é: " + fun.salario(6));

	}

}
