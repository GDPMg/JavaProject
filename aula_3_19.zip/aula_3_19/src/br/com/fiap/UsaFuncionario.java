package fiap.com.br;

import java.util.Scanner;

public class UsaFuncionario {

	public static void main(String[] args) {
		Funcionario fun = new Funcionario();
		Scanner scan;
		
		try {
			scan = new Scanner(System.in);
			System.out.println("insira seu nome");
			fun.setNome(scan.nextLine());
			System.out.println("Insira o valor da sua hora");
			fun.setValorHora(scan.nextFloat());
			System.out.println("Insira quantas horas trabalha por semana");
			System.out.println("O seu salário é: " + fun.salario(scan.nextInt()));
		} catch (Exception e) {
			System.out.println("Dados Inseridos incorretos");
		}

	}

}
